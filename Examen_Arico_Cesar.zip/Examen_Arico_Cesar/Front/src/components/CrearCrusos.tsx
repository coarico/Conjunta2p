import { useState } from 'react'
import type { Curso } from '../types'
import { crearCurso } from '../services/cursoService'

interface CrearCursoProps {
  userId: number
}

export default function CrearCurso({ userId }: CrearCursoProps) {
  const [curso, setCurso] = useState<Omit<Curso, 'id' | 'id_creador'>>({
    nombre: '',
    descripcion: '',
    estado: 'activo' // Valor por defecto
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setCurso({ ...curso, [e.target.name]: e.target.value })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    try {
      const cursoCompleto = {
        ...curso,
        id_creador: userId,
        estado: curso.estado || 'activo' // Asegurar que siempre tenga un estado
      }
      
      await crearCurso(cursoCompleto)
      alert('Curso creado exitosamente')
      
      // Limpiar el formulario
      setCurso({
        nombre: '',
        descripcion: '',
        estado: 'activo'
      })
      
    } catch (error) {
      console.error('Error al crear el curso:', error)
      alert('Error al crear el curso. Por favor, intente nuevamente.')
    }
  }

  return (
    <div className="card">
      <h3>Crear Curso</h3>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Nombre del Curso</label>
          <input 
            name="nombre" 
            value={curso.nombre}
            placeholder="Ingrese el nombre del curso" 
            onChange={handleChange} 
            required
            className="form-control"
          />
        </div>
        
        <div className="form-group">
          <label>Descripción</label>
          <input 
            name="descripcion" 
            value={curso.descripcion}
            placeholder="Ingrese una descripción" 
            onChange={handleChange}
            className="form-control"
          />
        </div>
        
        <div className="form-group">
          <label>Estado</label>
          <select 
            name="estado" 
            value={curso.estado}
            onChange={handleChange}
            className="form-control"
          >
            <option value="activo">Activo</option>
            <option value="inactivo">Inactivo</option>
            <option value="en_construccion">En Construcción</option>
          </select>
        </div>
        
        <input type="hidden" name="id_creador" value={userId} />
        
        <button type="submit" className="btn primary">
          Crear Curso
        </button>
      </form>
    </div>
  )
}
