import { useState } from 'react'
import type { Curso } from '../types'
import { obtenerCurso } from '../services/cursoService'

export default function ConsultarCurso() {
  const [id, setId] = useState<number>(0)
  const [curso, setCurso] = useState<Curso | null>(null)
  const [cargando, setCargando] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const buscar = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!id) {
      setError('Por favor ingrese un ID de curso válido')
      return
    }
    
    setCargando(true)
    setError(null)
    
    try {
      const data = await obtenerCurso(id)
      if (data) {
        setCurso(data)
      } else {
        setError('No se encontró el curso con el ID proporcionado')
        setCurso(null)
      }
    } catch (err) {
      console.error('Error al buscar el curso:', err)
      setError('Error al buscar el curso. Por favor, intente nuevamente.')
      setCurso(null)
    } finally {
      setCargando(false)
    }
  }

  return (
    <div className="card">
      <h3>Consultar Curso</h3>
      <form onSubmit={buscar}>
        <div className="form-group">
          <label>ID del Curso</label>
          <div style={{ display: 'flex', gap: '0.5rem' }}>
            <input 
              type="number" 
              className="form-control"
              placeholder="Ingrese el ID del curso" 
              value={id || ''}
              onChange={e => setId(Number(e.target.value))} 
              required
              min={1}
            />
            <button 
              type="submit" 
              className="btn primary"
              disabled={cargando}
            >
              {cargando ? 'Buscando...' : 'Buscar'}
            </button>
          </div>
        </div>
      </form>

      {error && (
        <div className="error-message" style={{ color: '#dc3545', marginTop: '1rem' }}>
          {error}
        </div>
      )}

      {curso && (
        <div className="card" style={{ 
          marginTop: '1.5rem',
          backgroundColor: '#2c3e50',
          color: '#ecf0f1',
          border: '1px solid #34495e',
          boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)'
        }}>
          <h4 style={{ 
            marginTop: 0,
            color: '#fff',
            borderBottom: '1px solid #34495e',
            paddingBottom: '0.75rem',
            marginBottom: '1.25rem'
          }}>
            Detalles del Curso
          </h4>
          
          <div className="form-group" style={{ marginBottom: '1.25rem' }}>
            <label style={{
              display: 'block',
              marginBottom: '0.5rem',
              color: '#bdc3c7',
              fontWeight: '500',
              fontSize: '0.9rem',
              textTransform: 'uppercase',
              letterSpacing: '0.5px'
            }}>Nombre</label>
            <div className="form-control" style={{
              backgroundColor: '#34495e',
              color: '#fff',
              padding: '0.75rem',
              borderRadius: '6px',
              border: '1px solid #2c3e50',
              fontSize: '1rem',
              lineHeight: '1.5',
              minHeight: '44px',
              display: 'flex',
              alignItems: 'center'
            }}>
              {curso.nombre}
            </div>
          </div>
          
          <div className="form-group" style={{ marginBottom: '1.25rem' }}>
            <label style={{
              display: 'block',
              marginBottom: '0.5rem',
              color: '#bdc3c7',
              fontWeight: '500',
              fontSize: '0.9rem',
              textTransform: 'uppercase',
              letterSpacing: '0.5px'
            }}>Descripción</label>
            <div className="form-control" style={{
              backgroundColor: '#34495e',
              color: '#ecf0f1',
              padding: '0.75rem',
              borderRadius: '6px',
              border: '1px solid #2c3e50',
              minHeight: '100px',
              whiteSpace: 'pre-wrap',
              lineHeight: '1.6',
              fontSize: '1rem'
            }}>
              {curso.descripcion || 'Sin descripción'}
            </div>
          </div>
          
          <div className="form-group" style={{ marginBottom: '1.25rem' }}>
            <label style={{
              display: 'block',
              marginBottom: '0.5rem',
              color: '#bdc3c7',
              fontWeight: '500',
              fontSize: '0.9rem',
              textTransform: 'uppercase',
              letterSpacing: '0.5px'
            }}>Estado</label>
            <div className="form-control" style={{
              backgroundColor: curso.estado === 'activo' ? '#27ae60' : 
                           curso.estado === 'inactivo' ? '#e74c3c' : '#f39c12',
              color: '#fff',
              padding: '0.75rem',
              borderRadius: '6px',
              border: 'none',
              textTransform: 'capitalize',
              fontWeight: '500',
              textAlign: 'center',
              display: 'inline-block',
              minWidth: '120px'
            }}>
              {curso.estado}
            </div>
          </div>
          
          <div className="form-group">
            <label style={{
              display: 'block',
              marginBottom: '0.5rem',
              color: '#bdc3c7',
              fontWeight: '500',
              fontSize: '0.9rem',
              textTransform: 'uppercase',
              letterSpacing: '0.5px'
            }}>Creado por (ID)</label>
            <div className="form-control" style={{
              backgroundColor: '#34495e',
              color: '#fff',
              padding: '0.75rem',
              borderRadius: '6px',
              border: '1px solid #2c3e50',
              fontSize: '1rem',
              display: 'inline-flex',
              alignItems: 'center',
              justifyContent: 'center',
              width: '60px',
              height: '44px'
            }}>
              {curso.id_creador}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
