import { useState } from 'react'
import { cambiarEstadoCurso } from '../services/cursoService'

export default function CambiarEstadoCurso() {
  const [id, setId] = useState<number | ''>('')
  const [estado, setEstado] = useState('activo')
  const [cargando, setCargando] = useState(false)
  const [mensaje, setMensaje] = useState<{texto: string, tipo: 'exito' | 'error'} | null>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!id) {
      setMensaje({ texto: 'Por favor ingrese un ID de curso válido', tipo: 'error' })
      return
    }
    
    setCargando(true)
    setMensaje(null)
    
    try {
      await cambiarEstadoCurso(Number(id), estado)
      setMensaje({ 
        texto: 'Estado del curso actualizado correctamente', 
        tipo: 'exito' 
      })
      // Limpiar el formulario después de 3 segundos
      setTimeout(() => {
        setId('')
        setEstado('activo')
        setMensaje(null)
      }, 3000)
    } catch (error) {
      console.error('Error al actualizar el estado:', error)
      setMensaje({ 
        texto: 'Error al actualizar el estado. Por favor, intente nuevamente.', 
        tipo: 'error' 
      })
    } finally {
      setCargando(false)
    }
  }

  return (
    <div className="card">
      <h3>Cambiar Estado del Curso</h3>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>ID del Curso</label>
          <input 
            type="number" 
            className="form-control"
            placeholder="Ingrese el ID del curso"
            value={id}
            onChange={e => setId(e.target.value === '' ? '' : Number(e.target.value))}
            required
            min={1}
          />
        </div>
        
        <div className="form-group">
          <label>Nuevo Estado</label>
          <select 
            className="form-control"
            value={estado}
            onChange={e => setEstado(e.target.value)}
            required
          >
            <option value="activo">Activo</option>
            <option value="inactivo">Inactivo</option>
            <option value="en_construccion">En Construcción</option>
          </select>
        </div>
        
        <div className="form-group">
          <button 
            type="submit" 
            className="btn primary"
            disabled={cargando}
          >
            {cargando ? 'Actualizando...' : 'Cambiar Estado'}
          </button>
        </div>
        
        {mensaje && (
          <div 
            className="mensaje" 
            style={{ 
              marginTop: '1rem',
              padding: '0.75rem',
              borderRadius: '4px',
              backgroundColor: mensaje.tipo === 'exito' ? '#d4edda' : '#f8d7da',
              color: mensaje.tipo === 'exito' ? '#155724' : '#721c24',
              border: `1px solid ${mensaje.tipo === 'exito' ? '#c3e6cb' : '#f5c6cb'}`
            }}
          >
            {mensaje.texto}
          </div>
        )}
      </form>
    </div>
  )
}
