import pg from 'pg';

const pool = new pg.Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'Cursos',
  password: '0808',
  port: 5432,
});

export default pool;
