import express from 'express';
import pool from '../db/conexion.js';
const router = express.Router();

// Crear curso
router.post('/', async (req, res) => {
  const { nombre, descripcion, estado = 'activo', id_creador } = req.body;
  
  // Validar campos requeridos
  if (!nombre || !id_creador) {
    return res.status(400).json({ 
      error: 'Los campos nombre e id_creador son obligatorios' 
    });
  }

  try {
    // Verificar que el usuario creador exista
    const usuarioExiste = await pool.query(
      'SELECT id FROM usuarios WHERE id = $1', 
      [id_creador]
    );

    if (usuarioExiste.rows.length === 0) {
      return res.status(404).json({ 
        error: 'El usuario creador no existe' 
      });
    }

    // Crear el curso
    const result = await pool.query(
      `INSERT INTO cursos (nombre, descripcion, estado, id_creador) 
       VALUES ($1, $2, $3, $4) 
       RETURNING *`,
      [nombre, descripcion, estado, id_creador]
    );

    res.status(201).json({ 
      mensaje: 'Curso creado exitosamente',
      curso: result.rows[0] 
    });
  } catch (err) {
    console.error('Error al crear curso:', err);
    
    // Manejar errores específicos de la base de datos
    if (err.code === '23505') { // Violación de restricción única
      return res.status(409).json({ 
        error: 'Ya existe un curso con ese nombre' 
      });
    }
    
    res.status(500).json({ 
      error: 'Error al crear curso',
      detalles: process.env.NODE_ENV === 'development' ? err.message : undefined
    });
  }
});

// Consultar curso
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query('SELECT * FROM cursos WHERE id = $1', [id]);
    if (result.rows.length === 0) return res.status(404).json({ mensaje: 'Curso no encontrado' });
    res.json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error al consultar curso' });
  }
});

// Cambiar estado de curso
router.put('/:id/estado', async (req, res) => {
  const { id } = req.params;
  const { nuevo_estado } = req.body;
  try {
    await pool.query('UPDATE cursos SET estado = $1 WHERE id = $2', [nuevo_estado, id]);
    res.json({ mensaje: 'Estado del curso actualizado' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error al actualizar estado' });
  }
});

export default router;
