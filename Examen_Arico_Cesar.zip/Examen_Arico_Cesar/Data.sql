-- ==========================
-- DUMP DE DATOS CORREGIDO
-- ==========================

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

-- Insertar usuarios
INSERT INTO public.usuarios VALUES 
(1, 'Cesar', 'Arico', 'cesar@mail.com', '123', 'creador'),
(3, 'Admin', 'Root', 'admin@admin.com', '12345678', 'administrador'),
(2, 'Josue', 'Delgado', 'josue@mail.com', '5678', 'consumidor')
ON CONFLICT DO NOTHING;

-- Insertar cursos
INSERT INTO public.cursos VALUES 
(1, 'Node.js Básico', 'Introducción al desarrollo backend con Node.js', 'activo', 1),
(2, 'React para principiantes', 'Frontend con React y Vite', 'en construcción', 1),
(3, 'Docker y Kubernetes', 'Curso avanzado de contenedores', 'inactivo', 1),
(4, 'Web3', 'programacion', 'Activo', 1)
ON CONFLICT DO NOTHING;

-- Insertar suscripciones
INSERT INTO public.suscripciones VALUES
(1, 2, 1),
(2, 2, 2),
(3, 2, 3)
ON CONFLICT DO NOTHING;

-- Ajustar secuencias
SELECT pg_catalog.setval('public.usuarios_id_seq', 3, true);
SELECT pg_catalog.setval('public.cursos_id_seq', 4, true);
SELECT pg_catalog.setval('public.suscripciones_id_seq', 3, true);
