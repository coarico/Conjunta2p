-- ================================================
-- SCHEMA DE LA BASE DE DATOS Cursos
-- (sin CREATE DATABASE ni \connect)
-- ================================================

-- Crear secuencias
CREATE SEQUENCE public.usuarios_id_seq
    AS integer START WITH 1 INCREMENT BY 1 NO MINVALUE NO MAXVALUE CACHE 1;

CREATE SEQUENCE public.cursos_id_seq
    AS integer START WITH 1 INCREMENT BY 1 NO MINVALUE NO MAXVALUE CACHE 1;

CREATE SEQUENCE public.suscripciones_id_seq
    AS integer START WITH 1 INCREMENT BY 1 NO MINVALUE NO MAXVALUE CACHE 1;

-- ================================================
-- Crear tablas
-- ================================================

CREATE TABLE public.usuarios (
    id integer NOT NULL DEFAULT nextval('public.usuarios_id_seq'),
    nombres character varying(100),
    apellidos character varying(100),
    email character varying(100),
    "contraseña" character varying(100),
    tipo_usuario character varying(50),
    CONSTRAINT usuarios_pkey PRIMARY KEY (id),
    CONSTRAINT usuarios_email_key UNIQUE (email)
);

CREATE TABLE public.cursos (
    id integer NOT NULL DEFAULT nextval('public.cursos_id_seq'),
    nombre character varying(100),
    descripcion text,
    estado character varying(20),
    id_creador integer,
    CONSTRAINT cursos_pkey PRIMARY KEY (id),
    CONSTRAINT cursos_id_creador_fkey FOREIGN KEY (id_creador) REFERENCES public.usuarios(id)
);

CREATE TABLE public.suscripciones (
    id integer NOT NULL DEFAULT nextval('public.suscripciones_id_seq'),
    usuario_id integer,
    curso_id integer,
    CONSTRAINT suscripciones_pkey PRIMARY KEY (id),
    CONSTRAINT suscripciones_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuarios(id),
    CONSTRAINT suscripciones_curso_id_fkey FOREIGN KEY (curso_id) REFERENCES public.cursos(id)
);
